<?php

    date_default_timezone_set('Asia/Dhaka');
    require_once 'db.php';
    ob_start();
    session_start();

?>