
    <section class="m-5 search-section">

<div class="container">
    <div class="row">
        <div class="col-md-10 mx-auto ">
            <form action="search.php" method="GET">
                <div class="input-group p-1">
                    <input type="search" class="form-control" placeholder="Search for books..." name="search_key">
                    <div class="input-group-append">
                      <button class="btn btn-secondary" type="submit" >Search</button>
                    </div>
                  </div>
            </form>
        </div>
    </div>
</div>

</section>